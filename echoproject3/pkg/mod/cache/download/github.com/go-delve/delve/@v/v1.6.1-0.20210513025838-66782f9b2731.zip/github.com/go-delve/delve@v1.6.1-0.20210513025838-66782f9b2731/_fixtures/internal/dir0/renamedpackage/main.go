package realname

type SomeType struct {
	A bool
}
